NET_IP=192.168.1.50
NET_PORT=27960
DEDICATED=1
CONFIG=defrag-mp.cfg

Q3_HOME="/usr/local/quake3"

cd $Q3_HOME
./q3ded +set fs_game defrag +set net_ip $NET_IP +set net_port $NET_PORT +set dedicated $DEDICATED +exec $CONFIG
