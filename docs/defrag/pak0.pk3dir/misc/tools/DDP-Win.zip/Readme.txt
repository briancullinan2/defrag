Defrag 1.9 Demo Pruner
Copyright 2003 Hard Core Game Design
almo@avalon.net

This program cleans up you Defrag demo directory, only leaving the demos with the best times.

Run the program, then select where your demo directory is, either by typing it, or by clicking the "Browse..." button.

There are a number of options for which demos to keep.

The "Number to keep per challenge" value sets the maximum number of demos allowed for a given map/physics/path configuration.

Check the "Only process this player" button, and enter a name if you want to only delete demos by a certain player.

Check the "Limit per player button" if you want to set a maximum on the number of demos kept per player.

This program assumes that you are using the Defrag 1.9 default naming system for your demos. For example:

rdrun[df.vq3]00.31.752(Almo!.UK).dm_68

where rdrun is the name of the map
df.vq3 is the physic model used and path taken
00.31.752 is the time
Almo!.UK is the player name and country

It won't process a directory with more than 4999 files in it.